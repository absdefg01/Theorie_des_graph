/**
 * Graphe orient� repr�sent� par ses listes d'adjacence
 */
public class GrapheOrienteList
{
    // instance variables - replace the example below with your own
    private int n;     // le nombre de sommets
    private int m;     // Le nombre d'arcs
    private Liste[]  G; // Le vecteur des liste d'adjacence

    /**
     * Constructeur du graphe (par d�faut, construction d'un graphe sans arc � n sommets) 
     */
    public GrapheOrienteList(int nb)
    {

        n = nb;
        m = 0;
        G = new Liste[n+1];
        for (int i = 1; i<=n; i++){
            G[i] = new Liste();
        }
    }

    /**
     * Constructeur du graphe (� partir des listes d'adjacence, sous forme
     *  d'un tableau � deux dimension{{succ de 1},{succ de 2},..,{succ de n}})
     *  
     *  Test : {{5},{1,4},{2},{3},{2,4}}
     */
    public GrapheOrienteList(int[][] T)
    {
        n = T.length;
        m = 0;
        G = new Liste[n+1];
        for(int i = 1; i<=n; i++){
            G[i] = new Liste(T[i-1]);
        }
    }

    /**
     * Mutateurs : ajout et suppression d'un arc 
     */
    public void ajoutArc(int i, int j)//vraie valeur index�s � partir de 1
    {  
        G[i].ajoutFin(j);
        G[i].tri();
        m++;
    }

    public void enleveArc(int i, int j)//vraie valeur index�s � partir de 1
    {  
        if(G[i].indice(j)!=-1){
            G[i].tri();
            G[i].enleveElt(j);
            m--;
        }else{
            System.out.println("Cet arc n'existe pas !!");
        }
    }

    /**
     * M�thodes 
     */
    public void affiche()
    { 
        System.out.print("[");
        for(int i = 1; i<=n; i++){
            G[i].affiche();
        }
        System.out.print("]");
    }

    public int degreS(int i)
    {
        int dS = 0;
        dS += G[i].taille();
        return dS;
    }

    public int[] degS()
    {  
        int[] dS = new int[n+1];
        for(int i = 1; i<=n; i++){
            dS[i] = degreS(i);
        }
        return dS;
    }

    public int[] degE()
    { 
        int[] dE = new int[n+1];
        for(int i = 1; i<=n; i++){
            for(int j = 0; j<G[i].taille(); j++){
                dE[G[i].elt(j)]+=1;
            }
        }
        return dE;
    }

    //conversion en GrapheMat
    public GrapheOrienteMat toMat()
    {  
        GrapheOrienteMat M = new GrapheOrienteMat(n);
        for(int i = 1; i<=n; i++){
            for(int j = 0; j<G[i].taille(); j++){
                int h = G[i].elt(j);
                M.ajoutArc(i,h);
            }
        }
        return M;
    }

    public static void main(){
        int[][] T= {{5},{1,4},{2},{3},{2,4}};
        GrapheOrienteList L = new GrapheOrienteList(T);
        L.affiche();
        System.out.println();
        GrapheOrienteMat M = L.toMat();
        M.affiche();
    }
}
