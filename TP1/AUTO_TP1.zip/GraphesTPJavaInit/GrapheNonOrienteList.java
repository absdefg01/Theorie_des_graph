
/**
 * Write a description of class GrapheNonOrienteList here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GrapheNonOrienteList
{
    private int n;
    private int m;
    private Liste[] G;

    /**
     * Constructor for objects of class GrapheNonOrienteList
     * {{2,5,5},{1,3,4,4},{2,3,4},{2,2,3,5},{1,1,4}}
     */ 
    public GrapheNonOrienteList(int nb)
    {
        n = nb;
        m = 0; 
        G = new Liste[n+1];
        for(int i = 1; i<=n; i++){
            G[i] = new Liste();
        }   
    }

    public GrapheNonOrienteList(int[][] T)
    {
        n = T.length;
        m = 0; 
        G = new Liste[n+1];
        for(int i = 1; i<=n; i++){
            G[i] = new Liste(T[i-1]);
            m++;
        }   
    }

    public void affiche(){
        System.out.print("[");
        for(int i = 1; i<=n; i++){
            G[i].affiche(); 
        }
        System.out.print("]");
    }

    public void ajoutArc(int i, int j){
        G[i].ajoutFin(j);
        G[i].tri();
        m++;
    }

    public void enleveArc(int i, int j){
        if(G[i].indice(j)!=-1){
            G[i].tri();
            G[i].enleveElt(j);
            m--;
        }else{
            System.out.println("Cet arc n'existe pas !!");
        }
    }

    public int degre(int i){
        int d = 0;
        d += G[i].taille();;
        return d;
    }

    public int[] degre(){
        int[] d = new int[n+1];
        for(int i = 1; i<=n; i++){
            d[i] = degre(i);
        }
        return d;
    }
    
    public GrapheNonOrienteMat toMat(){
        GrapheNonOrienteMat M = new GrapheNonOrienteMat(n);
        for(int i = 1; i<=n; i++){
            for(int j = 0; j<G[i].taille(); j++){
                int h = G[i].elt(j);
                M.ajoutArc(i,h);
            }
        }
        return M;
    }
    
    public static void main(){
        int[][] T = {{2,5,5},{1,3,4,4},{2,3,4},{2,2,3,5},{1,1,4}};
        GrapheNonOrienteList L = new GrapheNonOrienteList(T);
        L.affiche();
        System.out.println();
        GrapheNonOrienteMat M = L.toMat();
        M.affiche();
    }
}
