 


/**
 * Graphe orient� repr�sent� par sa matrice d'adjacence
 */
public class GrapheOrienteMat
{
    private int n;     // le nombre de sommets
    private int m;     // Le nombre d'arcs
    private int[][]  mat; // La matrice d'adjacence

/**
 * Constructeur du graphe (par d�faut, construction d'un graphe sans arc � n sommets) 
 */
public GrapheOrienteMat(int nb)
{
     n = nb;
     m = 0;
     mat = new int[n+1][n+1];
}
    
/**
 * Constructeur du graphe (� partir des listes d'adjacence, sous forme
 *  d'un tableau � deux dimension{{succ de 1},{succ de 2},..,{succ de n}})
 *  On en profite pour calculer les degr�s  sortants et entrant stock�s en mat[i,0] et mat[0,i]
 */
public GrapheOrienteMat(int[][] T)
{
    n = T.length;
    m = 0;
    mat = new int[n+1][n+1];
    for (int i = 0; i<n; i++){
        mat[i+1][0]=T[i].length;
       for (int j = 0; j<T[i].length; j++){
           mat[i+1][T[i][j]]=1;
           m++;
           mat[0][T[i][j]]++;
        }
    }
}
    
/**
 * Mutateur : Ajout  d'un arc
 */
    public void ajoutArc(int i, int j)
    {
        if (mat[i][j]==0){
            mat[i][j]=1;
            mat[i][0]++;
            mat[0][j]++;
            m++;
        } 
        else {System.out.println("Cet arc existe d�j�!");   
             } 
    }

/**
* Mutateur : Suppression d'un arc
*/    
public void enleveArc(int i, int j)
{
    if (mat[i][j]==1){
       mat[i][j]=0; 
       mat[i][0]--;
       mat[0][j]--;
       m--;}
    else {System.out.println("Arc inexistant!");   
         } 
 }
        
/**
 * Nombre de sommets du graphe
 */
  public int nbSommets()
{
     return n;
}

/**
  * Nombre d'arcs du graphe
*/
public int nbArcs()
{
     return m;
}
  
 /**
 * Affichage d'un graphe sous forme matricielle
 */
    public void affiche()
    {   System.out.println("Par matrice d'adjacence " );
        for (int i = 1; i<=n; i++){
            System.out.print("[" + mat[i][1]);
           for (int j = 2; j<=n; j++){
               System.out.print(", " + mat[i][j]);
            }
            System.out.println("]");
        }
        System.out.println("");
         
    }
 
/**
* Degr� sortant du sommet i
*/   
public int degreS(int i)/* C'est la somme des �l�ments de la ligne i */
{ int d=0;
    for (int j = 1; j<=n; j++){
        d+=mat[i][j];    
    }
  return d;   
}   
  
/**
* Degr� entrant du sommet i
*/
public int degreE(int j)/* C'est la somme des �l�ments de la colonne j */
{int d=0;
   for (int i = 1; i<=n; i++){
       d+=mat[i][j];
    }
 return d; 
     
}     
 
public Liste voisinageE(int j )/* liste des sommets i tels que mat[i][j] == 1  */
{Liste voisin = new Liste();
   for (int i = 1; i<=n; i++){
      if (mat[i][j]==1){
          voisin.ajoutFin(i);
        }
    }
 return voisin; 
     
}
   
/**
* Calcul du vecteur des degr�s sortants
*/ 
public int[] degS()
{  int[] D = new int[n+1];
   for (int i = 1; i<=n; i++){
       D[i]=degreS(i);
    }
     return D;
}
    
/**
* Calcul du vecteur des degr�s entrants
*/   
public int[] degE()
{  int[] D = new int[n+1];
   for (int i = 1; i<=n; i++){
       D[i]=degreE(i);
    }
     return D;
}
 
/**
 * Conversion d'un GrapheMat en GrapheList
 */ 
    
public GrapheOrienteList toList()
{   GrapheOrienteList L = new GrapheOrienteList(n);
    
    for (int i = 1; i<=n; i++){
       for (int j = 1; j<=n; j++){
       //on ajoute l'arc (i,j) s'il existe
       if (mat[i][j]==1){
           //System.out.println(" on ajoute l'arc " +i+" , "+j);
           L.ajoutArc(i,j);
           //L.affiche();
        }
    }
    }
    return L;
}
 
    
public static void main (){
    int[][] T1={{2,3},{4},{},{1,4}};
    GrapheOrienteMat M1 = new GrapheOrienteMat(T1);
    M1.affiche();
    GrapheOrienteList G1 = M1.toList();
    G1.affiche();

}

}





