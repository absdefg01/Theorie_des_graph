
/**
 * Write a description of class GrapheNonOrienteMat here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GrapheNonOrienteMat
{
    private int n;
    private int m;
    private int[][] mat;

    /**
     * Constructor for objects of class GrapheNonOrienteMat
     * {{2,5,5},{1,3,4,4},{2,3,4},{2,2,3,5},{1,1,4}}
     */
    public GrapheNonOrienteMat(int nb)
    {
        n = nb;
        m = 0;
        mat = new int[n+1][n+1];
    }

    public GrapheNonOrienteMat(int[][] T)
    {
        n = T.length;
        m = 0;
        mat = new int[n+1][n+1];
        for(int i = 1; i<=n; i++){
            for(int j = 1; j<=T[i-1].length; j++){
                mat[i][T[i-1][j-1]]+=1;
                m++;
            }
        }
    }

    public void ajoutArc(int i, int j){
        mat[i][j]+=1;
        m++;
    }

    public void enleveArc(int i, int j){
        if(mat[i][j]>0){
            mat[i][j]-=1;
            m--;
        }else{
            System.out.println("Cet arc n'existe pas !!");
        }
    }

    public int degre(int i){
        int d = 0;
        for(int j = 1; j<=n; j++){
            d += mat[i][j];
        }
        return d;
    }

    public int[] degre(){
        int[] d = new int[n+1];
        for(int i = 1; i<=n; i++){
            d[i] = degre(i);
        }
        return d;
    }

    public void affiche(){
        for(int i = 1; i<=n; i++){
            System.out.print("[ ");
            for(int j = 1; j<n; j++){
                System.out.print(mat[i][j] + ", ");
            }
            System.out.print(mat[i][n]);
            System.out.println(" ]");
        }
    }
    
    public GrapheNonOrienteList toList(){
        GrapheNonOrienteList L = new GrapheNonOrienteList(n);
        for(int i = 1; i<=n; i++){
            for(int j = 1; j<=n; j++){
                while(mat[i][j]>0){
                    L.ajoutArc(i,j);
                    mat[i][j]--;
                }
            }
        }
        return L;
    }
    
    public static void main(){
        int[][] T = {{2,5,5},{1,3,4,4},{2,3,4},{2,2,3,5},{1,1,4}};
        GrapheNonOrienteMat M = new GrapheNonOrienteMat(T);
        M.affiche();
        System.out.println();
        GrapheNonOrienteList L = M.toList();
        L.affiche();
    }
}
