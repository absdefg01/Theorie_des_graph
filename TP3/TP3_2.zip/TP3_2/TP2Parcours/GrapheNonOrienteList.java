
/**
 * Graphe orient� repr�sent� par ses listes d'adjacence
 */
public class GrapheNonOrienteList
{
    // instance variables - replace the example below with your own
    protected int n;     // le nombre de sommets
    protected int m;     // Le nombre d'arcs
    protected Liste[]  G; // Le vecteur des liste d'adjacence
    private Liste ordreVisite; 
    private int[] Visite;
    protected boolean cycle; //
    /**
     * Constructeur du graphe (par d�faut, construction d'un graphe sans arc � n sommets) 
     */
    public GrapheNonOrienteList(int nb)
    {

        n = nb;
        m = 0;
        G = new Liste[n+1];
        for (int i = 0; i<n; i++){
            G[i+1] = new Liste();
        }
    }

    /**
     * Constructeur du graphe (� partir des listes d'adjacence, sous forme
     *  d'un tableau � deux dimension{{succ de 1},{succ de 2},..,{succ de n}})
     *  Les listes d'adjacence  donn�es doivent �tre sym�triques.
     *  On autorise les boucles mais pas les liaisons multiples.
     */
    public GrapheNonOrienteList(int[][] T)
    {
        n = T.length;
        m = 0;
        G = new Liste[n+1];
        for (int i = 0; i<n; i++){
            G[i+1] = new Liste(T[i]);
            m += T[i].length;
            if (G[i+1].indice(i+1)!=-1){m++;} // on compte deux fois les boucles
        }
        m=m/2; //toutes les aretes sont compt�es deux fois
    }

    /**
     * Mutateurs : Ajout  d'un arc 
     */
    public void ajoutArete(int i, int j)//vraie valeur index�s � partir de 1
    {   G[i].ajoutFin(j);
        G[j].ajoutFin(i);
        m++; 
    }

    /**
     * Mutateurs : Suppression d'un arc 
     */
    public void enleveArete(int i, int j)//vraie valeur index�s � partir de 1
    {   G[i].enleveElt(j);
        G[j].enleveElt(i);
        m--; 
    }

    /**
     * Affichage d'un graphe par liste d'adjacence
     */
    public void affiche()
    {   System.out.print("Le graphe est d�fini par listes d'adjacence " );
        System.out.print("[ " );
        G[1].affiche();
        for (int i = 2; i<=n; i++){
            System.out.print(", " );
            G[i].affiche();
        }
        System.out.println(" ]" ); 
    }

    /**
     * Degr�  du sommet i 
     */
    public int degre(int i)
    {
        return G[i].taille();
    }

    /**
     * Calcul du vecteur des degr�s  
     */
    public int[] degre()
    {  int[] D = new int[n+1];
        for (int i = 1; i<=n; i++){
            D[i]=G[i].taille();
        }
        return D;
    }

    /**
     * Conversion en grapheMat
     */
    public GrapheNonOrienteMat toMat()
    {   GrapheNonOrienteMat M = new GrapheNonOrienteMat(n);

        for (int i = 1; i<=n; i++){
            for (int j = 0; j<G[i].taille(); j++){
                M.ajoutArete(i,G[i].elt(j)); //on ajoute l'arc
            }
        }
        return M;
    }

    public void profRec(int i){

        Visite[i] = 1;
        //         int z = 0;

        //ajouter le sommet i dans la liste d'ordreVisite
        ordreVisite.ajoutFin(i);

        //on parcours les succeseurs du sommet i
        for(int j = 0; j<G[i].taille();j++){

            int z = G[i].elt(j);
            if(Visite[z]==0){
                profRec(G[i].elt(j));               
            }
            //             System.out.println("On traite le sommet " + z);
        }

    }

    /* 
     * initialisation des variables globales et premier  appel � la fonction r�cursive 
     * profRec
     */ 
    public Liste profond(int i){
        ordreVisite = new Liste();
        Visite = new int[n+1];
        profRec(i);
        return ordreVisite; 
    }

    public boolean isConnexe(){
        return profond(1).taille()==n;
    }

    /**
     * Recherche des cycles par adaptation du parcours g�n�ralis�
     */

    public void cycleRec(int i, int pere){

        Visite[i] = 1;
        int z = 0;

        //ajouter le sommet i dans la liste d'ordreVisite
        ordreVisite.ajoutFin(i);

        //on parcours les succeseurs du sommet i
        for(int j = 0; j<G[i].taille()&!cycle;j++){

            z = G[i].elt(j);
            if(Visite[z]==0){
                System.out.println("appel r�cursif du sommet " +z);
                cycleRec(z,i);

            }else{
                System.out.println("Revisite du sommet " + z);

                if (z==pere) {
                    System.out.println("Je suis ton p�re");
                }else{
                    System.out.println("Cycle d�tect�");
                    cycle = true;
                    return;
                }
            }
            System.out.println("Fin du parcours du sommet " + i);
        }

    }

    public boolean isCyclic(){

        cycle = false;
        Visite = new int[n+1];
        for(int i=1; i<=n & !cycle;i++){
            if(Visite[i]==0){
                cycleRec(i,i); 
            }
        }
        System.out.println(cycle);
        return cycle;

    }

    /*
     * Test d'arbre
     */
    public boolean isArbre(){
        boolean res  = this.isConnexe() &! this.isCyclic();
        System.out.println("Test d'arbre : " + res);
        return res;    
    }

    public void plusCourtChemin(int i){
        int[] dist = new int[n+1];
        int[] pere = new int[n+1];

        Visite = new int[n+1];
        int y = 0; 
        int z = 0;
        dist[i] = 0;
        pere[i] = i;
        this.Visite[i]= 1;
        Liste F = new Liste();
        F.ajoutFin(i);


        while (!F.vide()) {
            y = F.tete();
            F.reste();
            for(int j = 0; j < G[y].taille(); j++){
                z = G[y].elt(j);
                if(Visite[z]==0){
                    Visite[z]=1;
                    F.ajoutFin(z);
                    dist[y] = dist[y] + 1;
                    pere[z] = y;
                }
            }

        }
        System.out.println("Vecteur de distance : ");
        for(int j = 1; j<=n; j++){
            System.out.print(dist[j] + ", ");
        }
        System.out.println("");

        System.out.println("Vecteur de pere");
        for(int j = 1; j<=n; j++){
            System.out.print(pere[j] +", ");
        }

    }
    public static void main (){
        int[][] T1={{2},{1,3,7},{2},{7},{7},{2,4,5,6}};
        int[][] T2={{2,4},{1,3,7},{2},{1,7},{7},{7},{2,4,5,6}};
        int[][] T3={{2},{1,3},{2},{7},{7},{7},{4,5,6}};
        int[][] Petersen={{2},{1,3},{2},{5,7},{4,7},{7},{4,5,6}};

        GrapheNonOrienteList G1 = new GrapheNonOrienteList(T1);
        GrapheNonOrienteList G2 = new GrapheNonOrienteList(T2);
        GrapheNonOrienteList G3 = new GrapheNonOrienteList(T3);
        GrapheNonOrienteList Peter = new GrapheNonOrienteList(Petersen);

        G2.plusCourtChemin(1);

    }
}

