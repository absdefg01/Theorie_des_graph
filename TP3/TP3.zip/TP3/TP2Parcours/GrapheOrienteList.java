import java.util.Collections;
import java.util.ArrayList;

/**
 * Graphe orient� repr�sent� par ses listes d'adjacence
 */
public class GrapheOrienteList
{
    // instance variables - replace the example below with your own
    protected int n;     // le nombre de sommets
    protected int m;     // Le nombre d'arcs
    protected Liste[]  G; // Le vecteur des liste d'adjacence
    protected Liste ordreVisite; 
    protected int[] Visite;
    protected Liste[] ordreVisiteG;

    /**
     * Constructeur du graphe (par d�faut, construction d'un graphe sans arc � n sommets) 
     */
    public GrapheOrienteList(int nb)
    {

        n = nb;
        m = 0;
        G = new Liste[n+1];
        for (int i = 0; i<n; i++){
            G[i+1] = new Liste();
        }
    }

    /**
     * Constructeur du graphe (� partir des listes d'adjacence, sous forme
     *  d'un tableau � deux dimension{{succ de 1},{succ de 2},..,{succ de n}})
     */
    public GrapheOrienteList(int[][] T)
    {
        n = T.length;
        m = 0;
        G = new Liste[n+1];
        for (int i = 0; i<n; i++){
            G[i+1] = new Liste(T[i]);
            m += T[i].length;
        }
    }

    /**
     * Nombre de sommets du graphe
     */

    public int nbSommets()
    {
        return n;
    }

    /**
     * Nombre d'arcs du graphe
     */
    public int nbArcs()
    {
        return m;
    }

    /**
     * Mutateurs : Ajout  d'un arc 
     */
    public void ajoutArc(int i, int j)//vraie valeur index�s � partir de 1
    {   G[i].ajoutFin(j);
        m++; 
    }

    /**
     * Mutateurs : Suppression d'un arc 
     */
    public void enleveArc(int i, int j)//vraie valeur index�s � partir de 1
    {   G[i].enleveElt(j);
        m--; 
    }

    /**
     * Affichage d'un graphe par liste d'adjacence
     */
    public void affiche()
    {   System.out.println("Le graphe est d�fini par listes d'adjacence : " );
        System.out.print("[ " );
        G[1].affiche();
        for (int i = 2; i<=n; i++){
            System.out.print(", " );
            G[i].affiche();
        }
        System.out.println(" ]" ); 
    }

    /**
     * Degr� sortant du sommet i 
     */
    public int degreS(int i)
    {
        return G[i].taille();
    }

    /**
     * Calcul du vecteur des degr�s sortants 
     */
    public int[] degS()
    {  int[] D = new int[n+1];
        for (int i = 1; i<=n; i++){
            D[i]=G[i].taille();
        }
        return D;
    }

    /**
     * Calcul du vecteur des degr�s entrant (en calculer un a le m�me co�t que les calculer tous 
     */
    public int[] degE()
    {  int[] D = new int[n+1];
        for (int i = 1; i<=n; i++){
            for (int j = 0; j<G[i].taille(); j++){
                D[G[i].elt(j)]+=1;
            }
        }
        return D;
    }

    /**
     * Conversion en grapheMat
     */
    public GrapheOrienteMat toMat()
    {   GrapheOrienteMat M = new GrapheOrienteMat(n);

        for (int i = 1; i<=n; i++){
            for (int j = 0; j<G[i].taille(); j++){
                M.ajoutArc(i,G[i].elt(j)); //on ajoute l'arc
            }
        }
        return M;
    }

    /* 
     * TP n� 2 : parcours en largeur � partir du sommet i
     */ 
    public Liste larg(int i){
        //initialiser l'ordreVisite
        //         int y = 5;

        //initialiser l'ordreVisite
        ordreVisite = new Liste();
        //initialiser la liste Visite
        Visite = new int[n+1];

        int y = 0; 
        int z = 0;

        //initialiser Visite du sommet i � vrai
        this.Visite[i]= 1;

        //initialiser la file d'attentes
        Liste F = new Liste();
        //ajouter sommet i dans la file d'attentes
        F.ajoutFin(i);
        //ajouter sommet i dains la liste d'ordre visite
        ordreVisite.ajoutFin(i);

        //tant que F n'est pas vide
        while (!F.vide()) {
            y = F.tete();
            F.reste();
            System.out.println("On parcours les successeurs de " + y);
            for(int j = 0; j < G[y].taille(); j++){
                z = G[y].elt(j);
                if(Visite[z]==0){
                    System.out.println(z + "n'est pas visit�");
                    Visite[z]=1;
                    ordreVisite.ajoutFin(z);
                    F.ajoutFin(z);
                }else{
                    System.out.println(z + "est d�j� visit�");
                }
                System.out.println("On traite l'�l�ment "+z);
            }
            //                 F.ajoutFin(z);
        }
        System.out.println("Ordre de visite � partir du sommet " + i);
        //afficher la liste d'ordreVisite
        //         ordreVisite.affiche();

        return ordreVisite;    
    }

    /**
     * Fonction d'appel
     */
    public Liste largeur(int i){
        Visite = new int[n+1];
        System.out.println("On lance un parcours en largeur � partir du point "+i);
        larg(i); 
        return ordreVisite;
    }

    /* 
     * Version g�n�ralis�e � tout le graphe
     */ 
    public Liste[] largeurG(){
        Liste[] ordreVisiteG = new Liste[n];
        int k=0;
        Visite = new int[n+1];
        for(int i = 1; i<n; i++){
            if(Visite[i]==0){
                ordreVisiteG[k]=larg(i); 
                ordreVisiteG[k].affiche();
                k++;
            }
        }

        return ordreVisiteG; 
    }

    /**
     *  Parcours en profondeur � partir du sommet i
     */

    /**
     *  Parcours en profondeur � partir du sommet i
     */

    public void profRec(int i){
        //Visite(i)=vrai
        Visite[i] = 1;
        int z = 0;
        
        //ajouter le sommet i dans la liste d'ordreVisite
        ordreVisite.ajoutFin(i);

        //on parcours les succeseurs du sommet i
        for(int j = 0; j<G[i].taille();j++){
            

//             int z = G[i].elt(j);

//             if(Visite[z]==0){
                profRec(G[i].elt(j));               
//             }
//             System.out.println("On traite le sommet " + z);
        }

    }

    /* 
     * initialisation des variables globales et premier  appel � la fonction r�cursive 
     * profRec
     */ 
    public Liste profond(int i){
        ordreVisite = new Liste();
        Visite = new int[n+1];
        profRec(i);
        return ordreVisite; 
    }

    /* 
     * Version g�n�ralis�e � tout le graphe
     */ 
    public Liste[] profondG(){
        int i=1; int k=0;
        ordreVisiteG = new Liste[n];
        Visite = new int[n+1];

        /*A compl�ter*/

        return ordreVisiteG; 
    }

    

    public static void main (){
        int[][] T1={{5},{1,4},{2},{3},{2,4}};
        int[][] T2={{5},{1,4,5},{2,4},{},{4}};
        int[][] T3={{3,5,6},{1},{2,4},{},{},{4}};
        int[][] Petersen={{2,5,6},{1,3,7},{2,4,8},{3,5,9},{1,4,10},{1,8,9},{2,9,10},{3,6,10},{4,6,7},{5,7,8}};

        GrapheOrienteList G1 = new GrapheOrienteList(T1);
        GrapheOrienteList G2 = new GrapheOrienteList(T2);
        GrapheOrienteList G3 = new GrapheOrienteList(T3);
        GrapheOrienteList Peter = new GrapheOrienteList(Petersen);

        //         G1.largeur(1);
        //         G2.largeur(1);
//         G2.largeurG();
        //         G3.largeur(1);
        G2.isConnexe();
    }
}
