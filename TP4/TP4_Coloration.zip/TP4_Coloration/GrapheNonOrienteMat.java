 


/**
 * Graphe orient� repr�sent� par sa matrice d'adjacence
 */
public class GrapheNonOrienteMat
{
    private int n;     // le nombre de sommets
    private int m;     // Le nombre d'arcs
    private int[][]  mat; // La matrice d'adjacence

/**
 * Constructeur du graphe (par d�faut, construction d'un graphe sans arc � n sommets) 
 */
public GrapheNonOrienteMat(int nb)
{
     n = nb;
     m = 0;
     mat = new int[n+1][n+1];
}

/**
 * Constructeur du graphe (� partir des listes d'adjacence, sous forme
 *  d'un tableau � deux dimension{{succ de 1},{succ de 2},..,{succ de n}})
 *  Les listes d'adjacence  donn�es doivent �tre sym�triques.
 *  On autorise les boucles mais pas les liaisons multiples.
 *  Les degr�s sont calcul�s � la vol�e et m�moris�s en colonne 0
 */
public GrapheNonOrienteMat(int[][] T)
{
n = T.length;
m = 0;
mat = new int[n+1][n+1];
for (int i = 0; i<n; i++){
   for (int j = 0; j<T[i].length; j++){
           mat[i+1][T[i][j]]=1;
           mat[i+1][0]++;
           m++;
       if (T[i][j]==i+1){
           m++;//on compte deux fois les boucles
        }
       }
    }
       m=m/2;
    }
    
   


/**
* Mutateur : Ajout  d'un arc
*/
public void ajoutArete(int i, int j)
{
    mat[i][j]=1;
    mat[j][i]=1;
    mat[i][0]++;
    if (i!=j){mat[j][0]++;}
    m++;
}

/**
* Mutateur : Suppression d'un arc
*/    
public void enleveArete(int i, int j)
{
    if (mat[i][j]==1){
       mat[i][j]=0;
       mat[j][i]=0;
       mat[i][0]--;
       if (i!=j){mat[j][0]--;};
       m--;}
    else {System.out.println("Arc inexistant!");   
         } 
 }

/**
 * Nombre de sommets du graphe
 */


public int nbSommets()
{
     return n;
}

/**
  * Nombre d'ar�tes du graphe
*/
public int nbAretes()
{
     return m;
}

/**
* Affichage d'un graphe sous forme matricielle
*/
public void affiche()
{   System.out.println("Par matrice d'adjacence " );
    for (int i = 1; i<=n; i++){
        System.out.print("[" + mat[i][1]);
       for (int j = 2; j<=n; j++){
           System.out.print(", " + mat[i][j]);
        }
        System.out.println("]");
    }
    System.out.println("");
     
}

/**
* Degr�  du sommet i. On utilise ici la colonne 0 de la matrice
*/   
public int degre(int i)
{
     return mat[i][0];
}

/**
* Calcul du vecteur des degr�s 
*/ 
public int[] deg()
{  int[] D = new int[n+1];
   for (int i = 1; i<=n; i++){
       D[i]=mat[i][0];
    }
     return D;
}

/**
* Conversion d'un GrapheMat en GrapheList. Identique au cas orient�, � part le type du r�sultat
*/ 

public GrapheNonOrienteList toList()
{   GrapheNonOrienteList L = new GrapheNonOrienteList(n);   
    for (int i = 1; i<=n; i++){
       for (int j = 1; j<=n; j++){
       //on ajoute l'arc (i,j) s'il existe
       if (mat[i][j]==1){
           System.out.println(" on ajoute l'arc " +i+" , "+j);
           L.ajoutArete(i,j);
           //L.affiche();
        }
    }
    }
    return L;
}


public static void main (){
    int[][] T1={{2,3,4},{1,4},{1},{1,2,4}};
    GrapheNonOrienteMat M1 = new GrapheNonOrienteMat(T1);
    M1.affiche();
    System.out.println(" Ce graphe poss�de  " +M1.nbAretes()+"  ar�tes");
    T1=new int[][] {{2,3,4},{4},{},{4}};
    M1 = new GrapheNonOrienteMat(T1);
    M1.affiche();
    System.out.println(" Ce graphe poss�de  " +M1.nbAretes()+"  ar�tes");
    

}
}
