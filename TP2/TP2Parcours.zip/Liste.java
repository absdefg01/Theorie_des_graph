
import java.util.Collections;
import java.util.ArrayList;


/**
 * On red�finit une classe liste � partir de la classe ArrayList existante 
 * pour renommer les primitives comme dans le poly de graphes
 */
public class Liste
{
    
    private  ArrayList<Integer> L;
    

    /**
     * Constructeur par d�faut �la liste vide
     */
    public Liste()
    {
        L = new ArrayList<Integer>();
            }

     /**
     * Constructeur � partir d'un tableau d'entier
     */
    public Liste(int[] T)
    {
        L = new ArrayList<Integer>();
        for (int i=0;i<T.length;i++){
            L.add(T[i]);
                    }
    }
    /**
     * retourne les �l�ments de la liste sous forme d'une ArrayList
     */
    public ArrayList<Integer> getListe ()
    {return L;   
    }
    
    /**
     * nombre d'�l�ments de la liste 
     */
    public int taille ()
    {return L.size();   
    }
    /**
     * Premier �l�ment de la liste (si non vide)
     */
    public int tete ()
    {return L.get(0);   
    }
    /**
     * Ajoute l'�l�ment a en fin de liste
     */
    public void ajoutFin (int a)
    {L.add(a);   
    }
    /**
     * Ajoute  l'�l�ment a en t�te de liste
     */
    public void ajoutTete (int a)
    {L.add(0,a);   
    }
    
    /**
     * insertion sans r�p�tition dans une liste tri�e (Pour coloration na�ve)
     */
    public void insere (int a)
    {int j=0;
             while (j<L.size() && a> L.get(j)){
                 j++;}
     if ((j==L.size()) ||  (a<L.get(j)))
         {L.add(j,a);}            
    }
    /**
     * Enleve le premier �l�ment de la liste (si non vide)
     */
    public void reste ()
    {L.remove(0);   
    }
    /**
     * Concat�ne la liste L2 en fin de liste
     */
    // L.concate(l2) concatene l2 à la liste L
    public void concate (Liste l2)
    {L.addAll(L.size(),l2.getListe());   
    }
    /**
     * Renvoie l'�l�ment d'indice i
     */
    public int elt (int i)
    {return L.get(i);
    }
    /**
     * Indice de la premi�re occurence de l'�l�ment a (ou -1)
     */
    public int indice (int a)
    {return L.indexOf(a);
    }
    /**
     * La liste est-elle vide?
     */
    public boolean vide ()
    {return L.isEmpty();
    } 
    /**
     * Enleve l'�l�ment d'indice i
     */
    public void enleveInd (int i)
    {L.remove(i);
    } 
    /**
     * Enleve l'�l�ment  i de la liste (s'il existe)
     */
    public void enleveElt (int i)
    {if (indice(i)>=0){L.remove(this.indice(i));}
    } 
    /**
     * Tri la liste dans l'ordre croissant
     */
    public void tri ()
    {Collections.sort(L);
    } 
    /**
     * Affichage de la liste
     */
    public void affiche ()
    { if (this.vide())
        {System.out.print("[ ] ");}
      else
        {System.out.print("[" + L.get(0));
         for (int i=1;i<L.size();i++)
           {System.out.print(", "+L.get(i));
           }
         System.out.print("]" );  
        }
       
    }
    // Copie (par valeur) d'une liste
    public Liste copie ()
    {Liste l = new Liste();
        for (int j = 0; j<L.size(); j++){
        l.ajoutFin(this.elt(j));
    }  
    return l;
    }
    // Minimum, on retourne la valeur
     public int minVal ()
    {int min=L.get(0);
        for (int j = 1; j<L.size(); j++){
        if (L.get(j)<min){
        min=L.get(j);}
    }  
    return min;
    }
    
    // Minimum, on retourne la valeur
     public int minInd ()
    {int min=L.get(0);
     int ind=0;   
        for (int j = 1; j<L.size(); j++){
        if (L.get(j)<min){
        min=L.get(j);
        ind=j;}
    }  
    return ind;
    }
    
    
  
    
    }

