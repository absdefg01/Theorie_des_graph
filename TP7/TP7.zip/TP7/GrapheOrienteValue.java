import java.util.*;
import java.lang.*;

/**
 * Write a description of class GrapheOrienteValue here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GrapheOrienteValue extends GrapheOrienteList
{
    private int[][] Poids;
    private ArrayList<int[]> ListeArete;

    public GrapheOrienteValue(int nb)
    {
        super(nb);
        Poids = new int[nb+1][nb+1];
        ListeArete = new ArrayList<int[]>();
    }

    public GrapheOrienteValue(int[][] T, int nb){
        super(nb);
        super.m=T.length;
        int i = 0; int j = 0; int p = 0;
        for(int k = 0; k<m; k++){
            i = T[k][1];
            j = T[k][2];
            p = T[k][3];
            Poids[i][j] = p;
            ListeArete.add(T[k]);
        }
    }

    public void affichePoids(){
        for(int i = 1; i<=n; i++){
            System.out.print("[ " + Poids[i][1]);
            for(int j = 2; j<=2; j++){
                System.out.print(", " + Poids[i][j]);
            }
            System.out.println(" ]");
        }
    }

    public static void afficheAretes(ArrayList<int[]> L){
        System.out.println("{");
        for(int i = 0; i<L.size(); i++){
            System.out.println("{");
            for(int j = 0; j<L.get(i).length; j++){
                int[] N = L.get(i);
                System.out.println(N[j] + " ");
            }
            System.out.println("}");
        }
        System.out.println("}");
    }

    public  void affiche(){
        super.affiche(); // Les listes d'adjacence
        this.affichePoids(); //La matrice des poids
        afficheAretes(this.ListeArete);
    }

    public void afficheV(int[] V,int taille)
    {
        System.out.print("[" );
        for(int i=1;i<=taille;i++)
        {
            System.out.print(V[i]+", ");
        }
        System.out.println("]" );
    }

    public void Dijkstra(int s){
        int[] D = new int[n+1];
        int[] P = new int[n+1];
        Liste M = new Liste();
        for(int i = 1; i<=n; i++){
            if(i==s){
                D[i]=0;
            }else{
                D[i]=8888;
            }
        }
        P[s] = s;
        M.ajoutFin(s);
        afficheV(D,n);
        afficheV(P,n);
        while(!M.vide()){
            int x = M.tete();
            M.reste();
            for(int j = 0; j<G[x].taille(); j++){
                int z = G[x].elt(j);
                int p = Poids[x][z] + D[x];
                if(p<D[z]){
                    D[z] = p;
                    P[z] = x;
                    M.ajoutFin(z);
                }
            }
            afficheV(D,super.n);
            afficheV(P,super.n);
        }

    }

    public static void main_v(){
        int[][] T = {{1,2,7},{1,5,6},{1,6,2},{2,3,4},{2,5,5},{3,4,1},{3,5,2},{4,5,3},{5,6,1} };
        GrapheNonOrienteValue Test = new GrapheNonOrienteValue(T,6);
        Test.affichePoids();

        int[][] T2= {{1,2,7},{1,3,8},{2,3,2},{2,4,3},{3,4,1}};
        GrapheNonOrienteValue Gv = new GrapheNonOrienteValue(T2,4);
        //         Gv.Kruskal();
    }
}
