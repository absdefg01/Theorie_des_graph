
/**
 * Graphe orient� repr�sent� par sa matrice d'adjacence
 */
public class GrapheOrienteMat
{
    private int n;     // le nombre de sommets
    private int m;     // Le nombre d'arcs
    private int[][]  mat; // La matrice d'adjacence

    /**
     * Constructeur du graphe (par d�faut, construction d'un graphe sans arc � n sommets) 
     */
    public GrapheOrienteMat(int nb)
    {
        n = nb;
        m = 0;
        mat = new int[n+1][n+1];
    }

    /**
     * Constructeur du graphe (� partir des listes d'adjacence, sous forme
     *  d'un tableau � deux dimension{{succ de 1},{succ de 2},..,{succ de n}})
     *  On en profite pour calculer les degr�s  sortants et entrant stock�s en mat[i,0] et mat[0,i]
     *  
     *  Test : {{5},{1,4},{2},{3},{2,4}}
     */
    public GrapheOrienteMat(int[][] T)
    {
        n = T.length;
        m = 0;
        mat = new int[n+1][n+1];
        for(int i = 1; i<=n; i++){
            for(int j = 1; j<=T[i-1].length; j++){
                mat[i][T[i-1][j-1]]=1;
                m++;
            }
        }        
    }

    /**
     * M�thodes associ�es
     */
    public int nbSommets()
    {
        return n;
    }

    public int nbArcs()
    {
        return m;
    }

    public void affiche()
    {
        for(int i = 1; i<=n; i++){
            System.out.print("[ ");
            for(int j = 1; j<n; j++){
                System.out.print(mat[i][j] + ", ");
            }
            System.out.print(mat[i][n]);
            System.out.println(" ]");
        }
    }

    public int degreS(int i)
    {
        int dS = 0;
        for(int j = 1; j<=n; j++){
            dS += mat[i][j];
        }
        return dS;
    }

    public int degreE(int i)
    {
        int dE = 0;
        for(int j = 1; j<=n; j++){
            dE += mat[j][i];
        }
        return dE;
    }

    public int[] degS()
    {  
        int[] dS = new int[n+1];
        for(int i = 1; i<=n; i++){
            dS[i] = degreS(i);
        }
        return dS;
    }

    public int[] degE()
    { 
        int[] dE = new int[n+1];
        for(int i = 1; i<=n; i++){
            dE[i]=degreE(i);
        }
        return dE;
    }

    /**
     * Mutateur : Ajout et suppression d'un arc
     */
    public void ajoutArc(int i, int j)
    {
        if(mat[i][j]==0){
            mat[i][j]=1;
            m++;
        }else{
            System.out.println("Cet arc existe d�j� !!");
        }
    }

    public void enleveArc(int i, int j)
    {
        if(mat[i][j]!=0){
            mat[i][j]=0;
        }else{
            System.out.println("Cet arc n'existe pas !!");
        }
    }

    public Liste voisinageE(int i){
        Liste voisin = new Liste();
        for(int j = 1; j<=n; j++){
            if(mat[j][i]!=0){
                voisin.ajoutFin(j);
            }
        }

        return voisin;
    }

    //conversion en GrapheList
    public GrapheOrienteList toList()
    {  
        GrapheOrienteList L = new GrapheOrienteList(n);
        for(int i = 1; i<=n; i++){
            for(int j = 1; j<=n; j++){
                if(mat[i][j]!=0){
                    L.ajoutArc(i,j);
                }
            }
        }
        return L;
    }
    
    public static void main(){
        int[][] T = {{5},{1,4},{2},{3},{2,4}};
        GrapheOrienteMat M = new GrapheOrienteMat(T);
        M.affiche();
        GrapheOrienteList L = M.toList();
        L.affiche();
    }

}
