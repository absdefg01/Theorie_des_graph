import java.util.*;
/**
 * Write a description of class GrapheNonOrienteValue here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GrapheNonOrienteValue extends GrapheNonOrienteList
{
    private int[][] Poids;
    private ArrayList<int[]> ListeArete;

    /**
     * Constructor for objects of class GrapheNonOrienteValue
     * un graphe � nb sommets sans ar�tes
     * int[][] T= {{1,2,7},{1,3,8},{2,3,2},{2,4,3},{3,4,1}};
    GrapheNonOrienteValue Gv = new GrapheNonOrienteValue(4,T);
     */
    public GrapheNonOrienteValue(int nb)
    {
        super(nb);
        Poids = new int[nb+1][nb+1];
        ListeArete = new ArrayList<int[]>();
    }

    public GrapheNonOrienteValue(int[][] T,int nb)
    {
        super(nb);
        super.m = T.length;
        Poids = new int[nb+1][nb+1];
        ListeArete = new ArrayList<int[]>();
        int i, j, p;
        for(int k = 0; k<m; k++){
            i = T[k][0];
            j = T[k][1];
            p = T[k][2];
            super.G[i].ajoutFin(j);
            super.G[j].ajoutFin(i);
            Poids[i][j] = p;
            Poids[j][i] = p;
            ListeArete.add(T[k]);
        }
    }

    public void affichePoids(){
        for(int i = 1; i<=n; i++){
            System.out.print("[ " + Poids[i][1]);
            for(int j = 2; j<=n; j++){
                System.out.print(", " + Poids[i][j]);
            }
            System.out.println(" ]");
        }

        System.out.println("");
    }

    public static void afficheAretes(ArrayList<int[]> L){
        for(int i = 0; i<L.size();i++){
            System.out.print("{ ");
            for(int j = 0; j<L.get(i).length;j++){
                int[] n = L.get(i);
                System.out.print(n[j] + " ");
            }
            System.out.print("}");
        }
    }

    public void affiche(){
        super.affiche(); // Les listes d'adjacence
        this.affichePoids(); //La matrice des poids
        afficheAretes(this.ListeArete);
    }

    public static ArrayList<int[]> triInsertion (ArrayList<int[]> L)
    {
        ArrayList<int[]> T = new ArrayList<int[]>();
        int[] arete;
        int p,j;
        for (int i = 0; i<L.size(); i++){ 
            arete=L.get(i);
            p=arete[2];// Le troisi?me ?l?ment du triplet est le poids
            // On ins?re x ? sa place dans T
            j=0;
            while (j<T.size() && p> T.get(j)[2]){
                j++;}

            T.add(j,arete);    
        }    
        return T;
    }

    public GrapheNonOrienteList Kruskal(){
        GrapheNonOrienteList K = new GrapheNonOrienteList(m);
        int Poid = 0;
        if(!isConnexe()){
            throw new IllegalArgumentException("Ce graphe n'est pas connexe");
        }else{
            ListeArete = triInsertion(ListeArete);
            if(K.nbArete()<=n-1){
                System.out.println("ici");
                for(int i = 0; i<m; i++){
                    int[] L = ListeArete.get(i);
                    int x = L[0];
                    int y = L[1];
                    int p = L[2];
                    K.ajoutArete(x,y);
                    Poid = Poid + p;
                    if(K.isCyclic()){
                        K.enleveArete(x,y);
                        Poid = Poid - p;
                    }
                }
            }

        }
        
        System.out.println(Poid);
        return K;

    }

    public static void main_V(){
        int[][] T = {{1,2,7},{1,5,6},{1,6,2},{2,3,4},{2,5,5},{3,4,1},{3,5,2},{4,5,3},{5,6,1} };
        GrapheNonOrienteValue Test = new GrapheNonOrienteValue(T,6);

        int[][] T2= {{1,2,7},{1,3,8},{2,3,2},{2,4,3},{3,4,1}};
        GrapheNonOrienteValue Gv = new GrapheNonOrienteValue(T2,4);
        Gv.Kruskal();
    }
}
