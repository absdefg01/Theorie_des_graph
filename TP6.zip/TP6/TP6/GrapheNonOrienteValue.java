import java.util.ArrayList;

public class GrapheNonOrienteValue extends GrapheNonOrienteList
{
    private int[][] Poids;
    private ArrayList<int[]> ListeArete;

    /**
     * Constructor for objects of class GrapheNonOrienteValue
     * construisant un graphe � nb sommets sans ar�tes
     */
    public GrapheNonOrienteValue(int nb)
    {
        super(nb);
        ListeArete = new ArrayList<int[]>();
        Poids = new int[n+1][n+1];
        m = ListeArete.size();
    }

    /**
     * qui � partir d'un vecteur d'ar�tes valu�es de la forme {i,j,poids(i,j)} 
     * construise les attributs du graphe 
     * (donc ses attributs en tant que GrapheNonOrienteList plus 
     * ses attributs sp�cifiques en tant que GrapheNonOrienteValue.
     * {{1,2,7},{1,5,6},{1,6,2},{2,3,4},{2,5,5},{3,4,1},{3,5,2},{4,5,3},{5,6,1}}
     */
    public GrapheNonOrienteValue(int nb, int[][] T){
        super(T);
        n = nb;
        m = T.length;
        ListeArete = new ArrayList<int[]>();
        Poids = new int[n+1][n+1];
        //nb : nb sommets
        for(int i = 0; i<m; i++){
            //sommet depart
            int m = T[i][0];
            //sommet arriv�
            int n = T[i][1];
            //poids d'ar�te
            int p = T[i][2];
            //ajouter le poid des ar�tes correspondants
            Poids[m][n] = p;
            Poids[n][m] = p;
            int[] v = {m,n,p}; 
            //cr�ation de liste d'ar�tes
            ListeArete.add(v);    
        }
    }

    /**
     * qui affiche la matrice des poids
     */
    public void affichePoids(){
        System.out.println("Par matrice d'adjacence " );
        for (int i = 1; i<=n; i++){
            System.out.print("[" + Poids[i][1]);
            for (int j = 2; j<=n; j++){
                System.out.print(", " + Poids[i][j]);
            }
            System.out.println("]");
        }
        System.out.println("");
    }

    /**
     * affiche la liste des ar�tes
     */
    public static void afficheAretes(ArrayList<int[]> L)
    {
        System.out.println("Le graphe est d�fini par listes d'ar�tes");
        if(L.size()==0){
            System.out.print("[ ]");
        }else{
            for (int i=1;i<L.size();i++)
            {
                int[] T = L.get(0);
                System.out.print("[" + T[0]);

                for(int y = 1; y<T.length; y++){
                    System.out.print(T[y]+ ",");
                }

                System.out.print(", "+L.get(i));
            }
            System.out.print("]" ); 
        }
    }

    /**
     * qui appelle les deux affichages pr�c�dents.
     */
    public void affiche(){
        affichePoids();
        afficheAretes(ListeArete);
    }

    public static void main_Value(){
        int[][] T = {{1,2,7},{1,5,6},{1,6,2},{2,3,4},{2,5,5},{3,4,1},{3,5,2},{4,5,3},{5,6,1}};
        GrapheNonOrienteValue V = new GrapheNonOrienteValue(6,T);
        //         V.affichePoids();
        ArrayList<int[]> L = new ArrayList<int[]>();
        V.affiche();
    }
}
